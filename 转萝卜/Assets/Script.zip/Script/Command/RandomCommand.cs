using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomCommand : ICommand
{
    public override void Execute(params object[] objects)
    {
        
    }

    
}
