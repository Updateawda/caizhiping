using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*public class PlayControll
{
   IPlayer player=new IPlayer();
    public void SetPlay(IPlayer player)
    {
        this.player = player;
    }
}*/
