using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class IcharacterFactory 
{
    public abstract void CreatPlay(params object[] date);
}
